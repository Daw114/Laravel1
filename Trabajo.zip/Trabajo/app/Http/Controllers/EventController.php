<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\User;
use App\Models\Event;

class EventController extends Controller
{

    public function listUsers(Event $event)
    {
        $users = $event->users;
        return response()->json(['message'=>null,'data'=>$users],200);
    }
    /**
     * Display a listing of the resource.
     */
    public function index()
    {
        $evets = Event::all();
        return response()->json(['message'=>null, 'data'=>$evets],status: 200);
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $request->validate([
            'event_name' => 'required|string|max:255',
            'event_detail' => 'required|string',
        ]);

        $event = new Event([
            'event_name' => $request->input('event_name'),
            'event_detail' => $request->input('event_detail'),
        ]);
        $event->save();

        return response()->json(['message' => 'Evento creado con éxito', 'data' => $event], 200);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(string $id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        //
    }
}
